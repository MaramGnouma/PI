export class Client {
    constructor(public idClient:number,public nom:String,public prenom:String,public adresse:String,
        public email:String,public DateNaissance:Date){

    }
}
