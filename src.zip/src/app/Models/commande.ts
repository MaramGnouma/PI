export class Commande {
   constructor(public idCommande:number,public dateCommande:Date){
    
   }
}
