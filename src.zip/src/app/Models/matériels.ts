export class Matériels {
   idProduit!: number;
   designation!: String;
   description!: String;
   prix!: number;
   photo!: String;
   marque!: String;
   quantite!: String;
   promotion!: number;
   categorie!: String
/*
  constructor(
    public idProduit: number,
    public designation: String,
    public description: String,
    public prix: number,
    public photo: String,
    public marque: String,
    public quantite: String,
    public promotion: number,
    public categorie: String
  ) {}*/
}
