export class Lignecommande {
    constructor(public idLigne:number,public quantite:number,public prix:number){
        
    }
}
