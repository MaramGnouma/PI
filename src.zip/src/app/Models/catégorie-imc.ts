export class CatégorieIMC {
    constructor(public idCategorie:number,public description:String,public nomCategorie:String,public image:String
        ,public seuilinf:number,public seuilsup:number){

    } 
}
