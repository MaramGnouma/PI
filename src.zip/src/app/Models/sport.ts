export class Sport {
  constructor(
    public idSport: number,
    public nomSport: String,
    public description: String,
    public image: String
  ) {}
}
