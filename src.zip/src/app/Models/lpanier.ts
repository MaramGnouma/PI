export class Lpanier {
      id!:number;
      numero!:number;
      annee!:number;
      idart!:number;
      libelle!:String;
      pv!:number;;
      qte!:number;
      montant!:number;
}
