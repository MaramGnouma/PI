export class User {
    constructor(  
        public id:number,      
        public password:String,
        public Nom:String,
        public Prenom:String,
        public telephone:number,
       public  Gmail:number,
       public Adresse:String,
        public username:String){
    }
       
}
