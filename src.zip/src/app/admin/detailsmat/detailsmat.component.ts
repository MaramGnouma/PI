import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detailsmat',
  templateUrl: './detailsmat.component.html',
  styleUrls: ['./detailsmat.component.css']
})
export class DetailsmatComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
